import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { Suspense, useMemo, useState } from "react";
import { fetchSales, fetchClients, brl, tons, daysSince } from "@/lib/agro";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";

const salesOpts = queryOptions({ queryKey: ["sales"], queryFn: fetchSales });
const clientsOpts = queryOptions({ queryKey: ["clients"], queryFn: fetchClients });

export const Route = createFileRoute("/_authenticated/reports")({
  loader: ({ context }) => {
    const qc = (context as { queryClient: import("@tanstack/react-query").QueryClient }).queryClient;
    return Promise.all([qc.ensureQueryData(salesOpts), qc.ensureQueryData(clientsOpts)]);
  },
  component: () => (
    <Suspense fallback={<div className="text-muted-foreground">Carregando…</div>}>
      <ReportsPage />
    </Suspense>
  ),
});

type Period = "today" | "week" | "month" | "year";

function startOf(p: Period): Date {
  const d = new Date();
  if (p === "today") return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (p === "week") { const w = new Date(d); w.setDate(d.getDate() - 7); return w; }
  if (p === "month") return new Date(d.getFullYear(), d.getMonth(), 1);
  return new Date(d.getFullYear(), 0, 1);
}

function ReportsPage() {
  const { data: sales } = useSuspenseQuery(salesOpts);
  const { data: clients } = useSuspenseQuery(clientsOpts);
  const [period, setPeriod] = useState<Period>("month");

  const since = startOf(period);
  const filtered = sales.filter((s) => new Date(s.sale_date) >= since);
  const totalTons = filtered.reduce((a, s) => a + Number(s.tons), 0);
  const totalCommission = filtered.reduce((a, s) => a + Number(s.total_commission), 0); // Correção do campo de comissão

  // Histórico Cronológico Detalhado (Ordenado do mais recente para o mais antigo)
  const salesOrdenadas = useMemo(() => {
    return [...sales].sort(
      (a, b) => new Date(b.sale_date).getTime() - new Date(a.sale_date).getTime()
    );
  }, [sales]);

  // last purchase per client
  const lastByClient = useMemo(() => {
    const m = new Map<string, string>();
    for (const s of sales) {
      const prev = m.get(s.client_id);
      if (!prev || s.sale_date > prev) m.set(s.client_id, s.sale_date);
    }
    return m;
  }, [sales]);

  function bucket(min: number, max?: number) {
    return clients.filter((c) => {
      const d = daysSince(lastByClient.get(c.id) ?? null);
      if (d === null) return min === 999;
      if (max == null) return d >= min;
      return d >= min && d < max;
    });
  }
  const inactive30 = bucket(30, 60);
  const inactive60 = bucket(60, 90);
  const inactive90 = bucket(90);
  const never = bucket(999);

  return (
    <div className="mx-auto max-w-5xl space-y-6">
      <div>
        <h1 className="font-display text-3xl font-semibold text-primary">Relatórios</h1>
        <p className="text-muted-foreground">Toneladas, comissão e estado da carteira.</p>
      </div>

      <Tabs value={period} onValueChange={(v) => setPeriod(v as Period)}>
        <TabsList>
          <TabsTrigger value="today">Hoje</TabsTrigger>
          <TabsTrigger value="week">Semana</TabsTrigger>
          <TabsTrigger value="month">Mês</TabsTrigger>
          <TabsTrigger value="year">Ano</TabsTrigger>
        </TabsList>
        <TabsContent value={period}>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            <Stat label="Vendas" value={String(filtered.length)} />
            <Stat label="Toneladas" value={tons(totalTons)} accent />
            <Stat label="Comissão" value={brl(totalCommission)} earth />
          </div>
        </TabsContent>
      </Tabs>

      {/* NOVO COMPONENTE: Histórico cronológico detalhado solicitado */}
      <Card className="w-full">
        <CardContent className="p-0">
          <div className="border-b border-border px-5 py-4 bg-muted/10">
            <h3 className="font-display text-base font-semibold text-primary">
              Histórico Cronológico Detalhado de Transações
            </h3>
            <p className="text-xs text-muted-foreground">
              Lista de transações ordenadas por data com identificação do produtor, insumo e volume.
            </p>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm border-collapse">
              <thead>
                <tr className="border-b border-border bg-muted/40 text-muted-foreground text-xs uppercase tracking-wider font-semibold">
                  <th className="py-3 px-5">Cód. Transação</th>
                  <th className="py-3 px-5">Data</th>
                  <th className="py-3 px-5">Nome do Produtor</th>
                  <th className="py-3 px-5">Insumo / Produto</th>
                  <th className="py-3 px-5 text-right">Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {salesOrdenadas.map((s) => {
                  const produtor = clients.find((c) => c.id === s.client_id);
                  const dataFormatada = s.sale_date 
                    ? new Date(s.sale_date).toLocaleDateString("pt-BR", { timeZone: "UTC" })
                    : "—";

                  return (
                    <tr key={s.id} className="hover:bg-muted/30 transition-colors">
                      <td className="py-3 px-5 font-mono text-xs text-muted-foreground max-w-[120px] truncate" title={s.id}>
                        {s.id.substring(0, 8)}...
                      </td>
                      <td className="py-3 px-5 whitespace-nowrap text-foreground">
                        {dataFormatada}
                      </td>
                      <td className="py-3 px-5 font-medium text-foreground">
                        {produtor ? produtor.name : "Produtor Não Identificado"}
                      </td>
                      <td className="py-3 px-5 text-muted-foreground">
                        {s.product || "Insumo Geral"}
                      </td>
                      <td className="py-3 px-5 text-right font-semibold text-primary">
                        {tons(Number(s.tons || 0))}
                      </td>
                    </tr>
                  );
                })}

                {salesOrdenadas.length === 0 && (
                  <tr>
                    <td colSpan={5} className="py-10 text-center text-muted-foreground">
                      Nenhuma transação comercial registada no histórico.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div>
        <h2 className="mb-3 font-display text-xl font-semibold text-primary">Clientes inativos</h2>
        <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-4">
          <Pill label="Sem compra 30+ d" value={inactive30.length} />
          <Pill label="Sem compra 60+ d" value={inactive60.length} />
          <Pill label="Sem compra 90+ d" value={inactive90.length} />
          <Pill label="Nunca compraram" value={never.length} />
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, accent, earth }: { label: string; value: string; accent?: boolean; earth?: boolean }) {
  const cls = earth ? "text-earth" : accent ? "text-primary" : "text-foreground";
  return (
    <Card>
      <CardContent className="p-5">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className={`mt-1 font-display text-3xl font-semibold ${cls}`}>{value}</div>
      </CardContent>
    </Card>
  );
}

function Pill({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
        <div className="mt-1 font-display text-2xl font-semibold text-foreground">{value}</div>
      </CardContent>
    </Card>
  );
}