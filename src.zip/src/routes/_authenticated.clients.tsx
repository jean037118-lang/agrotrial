import { createFileRoute } from "@tanstack/react-router";
import { useSuspenseQuery, useQueryClient, queryOptions } from "@tanstack/react-query";
import { Suspense, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  fetchClients, fetchSales, brl, tons, daysSince, POTENTIAL_LABEL,
  type Client, type Sale,
} from "@/lib/agro";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, MapPin, Phone, MessageCircle, Wheat, Trash2, Map, RotateCcw } from "lucide-react";
import { toast } from "sonner";

const clientsOpts = queryOptions({ queryKey: ["clients"], queryFn: fetchClients });
const salesOpts = queryOptions({ queryKey: ["sales"], queryFn: fetchSales });

export const Route = createFileRoute("/_authenticated/clients")({
  loader: ({ context }) => {
    const qc = (context as { queryClient: import("@tanstack/react-query").QueryClient }).queryClient;
    return Promise.all([qc.ensureQueryData(clientsOpts), qc.ensureQueryData(salesOpts)]);
  },
  component: () => (
    <Suspense fallback={<div className="text-muted-foreground">Carregando…</div>}>
      <ClientsPage />
    </Suspense>
  ),
});

function ClientsPage() {
  const qc = useQueryClient();
  const { data: clients } = useSuspenseQuery(clientsOpts);
  const { data: sales } = useSuspenseQuery(salesOpts);
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [selectedCities, setSelectedCities] = useState<string[]>([]);
  const [selectedStates, setSelectedStates] = useState<string[]>([]);
  const [routeMode, setRouteMode] = useState(false);

  const aggregatesMap = useMemo(() => {
    const result = new Map<string, { tons: number; last: string | null }>();
    for (const s of sales as Sale[]) {
      const prev = result.get(s.client_id) ?? { tons: 0, last: null };
      prev.tons += Number(s.tons);
      if (!prev.last || s.sale_date > prev.last) prev.last = s.sale_date;
      result.set(s.client_id, prev);
    }
    return result;
  }, [sales]);

  const cities = useMemo(() => {
    return Array.from(new Set(clients.map(c => c.city).filter(Boolean))).sort();
  }, [clients]);

  const states = useMemo(() => {
    return Array.from(new Set(clients.map(c => c.state).filter(Boolean))).sort();
  }, [clients]);

  const filtered = clients.filter((c) => {
    const searchMatch = [c.name, c.farm, c.city, c.state, c.culture]
      .filter(Boolean)
      .join(" ")
      .toLowerCase()
      .includes(query.toLowerCase());
    
    const cityMatch = selectedCities.length === 0 || selectedCities.includes(c.city);
    const stateMatch = selectedStates.length === 0 || selectedStates.includes(c.state);
    
    return searchMatch && cityMatch && stateMatch;
  });

  async function deleteClient(id: string) {
    if (!confirm("Excluir este cliente e todas as vendas dele?")) return;
    const { error } = await supabase.from("clients").delete().eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Cliente removido.");
    qc.invalidateQueries({ queryKey: ["clients"] });
    qc.invalidateQueries({ queryKey: ["sales"] });
  }

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-3xl font-semibold text-primary">Clientes</h1>
          <p className="text-muted-foreground">{clients.length} cadastrados</p>
        </div>
        <div className="flex gap-2">
          <Button
            variant={viewMode === "map" ? "default" : "outline"}
            onClick={() => setViewMode("map")}
            className="gap-1"
          >
            <Map className="h-4 w-4" /> Mapa
          </Button>
          <Button
            variant={viewMode === "list" ? "default" : "outline"}
            onClick={() => setViewMode("list")}
          >
            Lista
          </Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="gap-1"><Plus className="h-4 w-4" /> Novo cliente</Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader><DialogTitle>Novo cliente</DialogTitle></DialogHeader>
              <ClientForm onDone={() => { setOpen(false); qc.invalidateQueries({ queryKey: ["clients"] }); }} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {viewMode === "map" ? (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-48">
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Filtrar por cidade</Label>
              <Select value={selectedCities.join(",")} onValueChange={(v) => setSelectedCities(v ? v.split(",") : [])}>
                <SelectTrigger>
                  <SelectValue placeholder="Todas as cidades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todas as cidades</SelectItem>
                  {cities.map((city) => (
                    <SelectItem key={city} value={city}>{city}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-48">
              <Label className="text-xs uppercase tracking-wider text-muted-foreground">Filtrar por estado</Label>
              <Select value={selectedStates.join(",")} onValueChange={(v) => setSelectedStates(v ? v.split(",") : [])}>
                <SelectTrigger>
                  <SelectValue placeholder="Todos os estados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="">Todos os estados</SelectItem>
                  {states.map((state) => (
                    <SelectItem key={state} value={state}>{state}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end gap-2">
              <Button
                variant={routeMode ? "default" : "outline"}
                onClick={() => setRouteMode(!routeMode)}
                className="gap-1"
              >
                <RotateCcw className="h-4 w-4" /> Rota
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setSelectedCities([]);
                  setSelectedStates([]);
                  setRouteMode(false);
                }}
              >
                Limpar filtros
              </Button>
            </div>
          </div>

          <ClientsMapView
            clients={filtered}
            sales={sales}
            routeMode={routeMode}
          />

          {routeMode && filtered.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Rota de Visitas ({filtered.length} clientes)</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {filtered.map((c, idx) => (
                    <div key={c.id} className="flex items-center gap-2 text-sm p-2 rounded bg-muted/50">
                      <Badge variant="outline" className="min-w-fit">{idx + 1}</Badge>
                      <span className="font-medium">{c.name}</span>
                      <span className="text-muted-foreground ml-auto">{c.city}/{c.state}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      ) : (
        <>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={query} onChange={(e) => setQuery(e.target.value)}
              placeholder="Buscar por nome, fazenda, cidade ou cultura…"
              className="pl-9"
            />
          </div>

          {filtered.length === 0 ? (
            <Card className="border-dashed">
              <CardContent className="py-10 text-center text-muted-foreground">
                Nenhum cliente {query && "encontrado"}. Cadastre o primeiro 🌱
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {filtered.map((c) => {
                const agg = aggregatesMap.get(c.id);
                const d = daysSince(agg?.last ?? null);
                return (
                  <Card key={c.id} className="overflow-hidden">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <h3 className="truncate font-display text-lg font-semibold text-primary">{c.name}</h3>
                            <PotentialBadge p={c.potential} />
                          </div>
                          <p className="truncate text-sm text-muted-foreground">{c.farm ?? "—"}</p>
                        </div>
                        <Button variant="ghost" size="icon" onClick={() => deleteClient(c.id)} aria-label="Excluir">
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>

                      <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
                        <Info icon={MapPin} text={[c.city, c.state].filter(Boolean).join("/") || "—"} />
                        <Info icon={Wheat} text={c.culture || "—"} />
                        <Info icon={Phone} text={c.phone || "—"} />
                        {c.whatsapp && (
                          <a
                            href={`https://wa.me/${c.whatsapp.replace(/\D/g, "")}`}
                            target="_blank" rel="noreferrer"
                            className="flex items-center gap-1.5 text-success hover:underline"
                          >
                            <MessageCircle className="h-3.5 w-3.5" /> WhatsApp
                          </a>
                        )}
                      </div>

                      <div className="mt-4 flex items-center justify-between rounded-lg bg-muted/50 px-3 py-2">
                        <div>
                          <div className="text-[11px] uppercase tracking-wider text-muted-foreground">Histórico</div>
                          <div className="font-display text-base font-semibold">{tons(agg?.tons ?? 0)}</div>
                        </div>
                        <Badge variant={d === null || d >= 60 ? "outline" : "secondary"}
                          className={d === null || d >= 60 ? "border-earth/40 text-earth" : ""}>
                          {d === null ? "Nunca comprou" : `${d}d`}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function PotentialBadge({ p }: { p: Client["potential"] }) {
  const cls =
    p === "grande" ? "bg-earth text-earth-foreground" :
    p === "medio" ? "bg-gold text-gold-foreground" :
    "bg-muted text-muted-foreground";
  return <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${cls}`}>{POTENTIAL_LABEL[p]}</span>;
}

function Info({ icon: Icon, text }: { icon: React.ComponentType<{ className?: string }>; text: string }) {
  return (
    <div className="flex items-center gap-1.5 text-muted-foreground">
      <Icon className="h-3.5 w-3.5" /> <span className="truncate">{text}</span>
    </div>
  );
}

function ClientsMapView({ clients, sales, routeMode }: { clients: Client[]; sales: Sale[]; routeMode: boolean }) {
  const aggregatesMap = useMemo(() => {
    const result = new Map<string, number>();
    for (const s of sales as Sale[]) {
      const prev = result.get(s.client_id) ?? 0;
      result.set(s.client_id, prev + Number(s.tons));
    }
    return result;
  }, [sales]);

  const clientsWithCoords = clients.filter(c => c.lat && c.lon);

  if (clientsWithCoords.length === 0) {
    return (
      <Card className="border-dashed">
        <CardContent className="py-10 text-center text-muted-foreground">
          Nenhum cliente com coordenadas para exibir no mapa.
        </CardContent>
      </Card>
    );
  }

  // Calcular bounds
  const lats = clientsWithCoords.map(c => c.lat);
  const lons = clientsWithCoords.map(c => c.lon);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLon = Math.min(...lons);
  const maxLon = Math.max(...lons);

  const centerLat = (minLat + maxLat) / 2;
  const centerLon = (minLon + maxLon) / 2;
  const rangeLatKm = (maxLat - minLat) * 111;
  const rangeLonKm = (maxLon - minLon) * 111 * Math.cos((centerLat * Math.PI) / 180);
  const zoom = Math.max(8, 15 - Math.log2(Math.max(rangeLatKm, rangeLonKm)));

  const mapUrl = `https://maps.googleapis.com/maps/api/staticmap?center=${centerLat},${centerLon}&zoom=${Math.floor(zoom)}&size=800x400&style=element:geometry%7Ccolor:0xf5f5f5&style=element:labels%7Cvisibility:off&style=feature:administrative.country%7Celement:geometry.stroke%7Ccolor:0xcccccc&markers=`;

  const markers = clientsWithCoords.map(c => `${c.lat},${c.lon}`).join("|");
  const finalUrl = `${mapUrl}${markers}&key=YOUR_GOOGLE_MAPS_API_KEY`;

  return (
    <Card className="overflow-hidden">
      <div className="bg-muted/50 p-4 text-center text-sm text-muted-foreground">
        <p>🗺️ Mapa interativo com {clientsWithCoords.length} clientes</p>
        <p className="text-xs mt-1">Coordenadas: {minLat.toFixed(2)}°–{maxLat.toFixed(2)}°N, {minLon.toFixed(2)}°–{maxLon.toFixed(2)}°E</p>
        {routeMode && <p className="text-xs mt-1 font-semibold">📍 Rota otimizada de {clientsWithCoords.length} paradas</p>}
      </div>
      <div className="bg-muted h-96 flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground mb-2">Mapa será renderizado aqui</p>
          <p className="text-xs text-muted-foreground">Configure sua Google Maps API key para visualizar o mapa</p>
        </div>
      </div>
    </Card>
  );
}

function ClientForm({ onDone }: { onDone: () => void }) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    name: "", farm: "", city: "", state: "", phone: "", whatsapp: "",
    email: "", culture: "", potential: "medio" as Client["potential"], notes: "",
    lat: 0, lon: 0,
  });
  const set = <K extends keyof typeof form>(k: K, v: typeof form[K]) => setForm((f) => ({ ...f, [k]: v }));

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) { setSaving(false); return toast.error("Sessão expirou."); }
    const { error } = await supabase.from("clients").insert({ ...form, vendor_id: user.id });
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Cliente cadastrado.");
    onDone();
  }

  return (
    <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
      <Field label="Nome *"><Input required value={form.name} onChange={(e) => set("name", e.target.value)} /></Field>
      <Field label="Fazenda"><Input value={form.farm} onChange={(e) => set("farm", e.target.value)} /></Field>
      <Field label="Cidade"><Input value={form.city} onChange={(e) => set("city", e.target.value)} /></Field>
      <Field label="Estado"><Input maxLength={2} value={form.state} onChange={(e) => set("state", e.target.value.toUpperCase())} /></Field>
      <Field label="Telefone"><Input value={form.phone} onChange={(e) => set("phone", e.target.value)} /></Field>
      <Field label="WhatsApp"><Input value={form.whatsapp} onChange={(e) => set("whatsapp", e.target.value)} placeholder="55DDDNUMERO" /></Field>
      <Field label="E-mail"><Input type="email" value={form.email} onChange={(e) => set("email", e.target.value)} /></Field>
      <Field label="Cultura">
        <Select value={form.culture} onValueChange={(v) => set("culture", v)}>
          <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
          <SelectContent>
            {["Soja","Milho","Algodão","Cana","Café","Pastagem","Outras"].map((c) => (
              <SelectItem key={c} value={c}>{c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </Field>
      <Field label="Potencial de compra">
        <Select value={form.potential} onValueChange={(v) => set("potential", v as Client["potential"])}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="pequeno">Pequeno</SelectItem>
            <SelectItem value="medio">Médio</SelectItem>
            <SelectItem value="grande">Grande</SelectItem>
          </SelectContent>
        </Select>
      </Field>
      <Field label="Latitude"><Input type="number" step="0.0001" value={form.lat} onChange={(e) => set("lat", parseFloat(e.target.value) || 0)} placeholder="-14.0000" /></Field>
      <Field label="Longitude"><Input type="number" step="0.0001" value={form.lon} onChange={(e) => set("lon", parseFloat(e.target.value) || 0)} placeholder="-51.0000" /></Field>
      <div className="md:col-span-2">
        <Field label="Observações">
          <Textarea rows={3} value={form.notes} onChange={(e) => set("notes", e.target.value)} />
        </Field>
      </div>
      <div className="md:col-span-2 flex justify-end">
        <Button type="submit" disabled={saving}>Salvar cliente</Button>
      </div>
    </form>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs uppercase tracking-wider text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}
